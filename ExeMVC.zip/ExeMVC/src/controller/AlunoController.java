/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import model.Aluno;

/**
 *
 * @author professor
 */
public class AlunoController {
    
    private ArrayList<Aluno> lista;

    
    public AlunoController() {
        lista = new ArrayList();
    }
    
    public void cadastrar(int ra, String nome)
    {
        Aluno al = new Aluno (ra, nome);
        lista.add(al);
        System.out.println(al.getRa() + "  " + al.getNome());
    }

    public ArrayList<Aluno> getLista() {
        return lista;
    }

    public void setLista(ArrayList<Aluno> lista) {
        this.lista = lista;
    }
    
    public void excluir (int ra)
    {
       for(Aluno a: lista)
       {
           if(a.getRa()==ra)
           {
               lista.remove(a);
               break;
           }
       }
    }
}
